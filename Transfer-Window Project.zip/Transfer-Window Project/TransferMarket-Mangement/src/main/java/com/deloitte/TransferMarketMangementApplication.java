package com.deloitte;
import org.springframework.web.client.RestTemplate;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class TransferMarketMangementApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransferMarketMangementApplication.class, args);
	}
	@Bean
	public RestTemplate getrestRestTemplate() {
		return new RestTemplate();
	}
}
