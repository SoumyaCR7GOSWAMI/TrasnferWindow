package com.deloitte.controller;

import java.util.List;

import org.apache.hc.core5.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.deloitte.entity.Club;
import com.deloitte.service.ClubService;

@RestController
@RequestMapping("/club")
public class ClubController {

	@Autowired
	ClubService clubService;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Club>> getAllPlayers()
	
	{
		List<Club> club = clubService.getAll();
		return new ResponseEntity<List<Club>>(club,org.springframework.http.HttpStatus.OK);
		
	}
	
}
