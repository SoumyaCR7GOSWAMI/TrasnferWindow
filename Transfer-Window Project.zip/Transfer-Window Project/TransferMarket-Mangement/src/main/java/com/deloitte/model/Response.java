package com.deloitte.model;

import java.util.List;

import com.deloitte.athlete.entity.Athlete;
import com.deloitte.entity.Club;

public class Response {

	
		private List<Club> ClubResponse;
		private List<Athlete> AthleteResponse;
		public Response() {
		super();
		// TODO Auto-generated constructor stub
	}
	
		public Response(List<Club> clubResponse, List<Athlete> athleteResponse) {
			super();
			ClubResponse = clubResponse;
			AthleteResponse = athleteResponse;
		}

		public List<Club> getClubResponse() {
			return ClubResponse;
		}

		public void setClubResponse(List<Club> clubResponse) {
			ClubResponse = clubResponse;
		}

		public List<Athlete> getAthleteResponse() {
			return AthleteResponse;
		}

		public void setAthleteResponse(List<Athlete> athleteResponse) {
			AthleteResponse = athleteResponse;
		}
}
	
		
		
