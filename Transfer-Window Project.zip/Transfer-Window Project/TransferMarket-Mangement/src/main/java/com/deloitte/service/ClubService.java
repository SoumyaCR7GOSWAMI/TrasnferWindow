package com.deloitte.service;

import java.util.List;

import com.deloitte.entity.Club;

public interface ClubService {

	public List<Club> getAll();

	public List<Club> getClub();
}
