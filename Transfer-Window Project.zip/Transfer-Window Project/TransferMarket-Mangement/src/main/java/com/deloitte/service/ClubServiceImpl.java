package com.deloitte.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.entity.Club;
import com.deloitte.repo.ClubRepo;

@Service
public class ClubServiceImpl implements ClubService {

	@Autowired
	ClubRepo clubRepo;
	
	@Override
	public List<Club> getAll() {
		List<Club> allPlayers = clubRepo.findAll();
		return allPlayers;
	}

	@Override
	public List<Club> getClub() {
		// TODO Auto-generated method stub
		return null;
	}

}
