package com.deloitte.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.deloitte.entity.Club;


public interface ClubRepo extends JpaRepository<Club, Integer>{
public List<Club> findBycid(Integer cid);
}
