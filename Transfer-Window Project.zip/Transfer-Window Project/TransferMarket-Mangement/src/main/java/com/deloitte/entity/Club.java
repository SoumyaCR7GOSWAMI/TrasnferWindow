package com.deloitte.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name= "club")
public class Club {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int pnum;
	private int cid;
	private String pname;
	

	public Club() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Club(int pnum, String pname, int cid) {
		super();
		this.pnum=pnum;
		this.cid = cid;
		this.pname = pname;
	}

	public int getPnum() {
		return pnum;
	}

	public void setPnum(int pnum) {
		this.pnum = pnum;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}
}
	

	