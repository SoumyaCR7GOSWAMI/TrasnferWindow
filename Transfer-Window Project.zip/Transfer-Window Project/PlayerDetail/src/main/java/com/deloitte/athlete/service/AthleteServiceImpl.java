package com.deloitte.athlete.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.athlete.entity.Athlete;
import com.deloitte.athlete.repo.AthleteRepo;


@Service
public class AthleteServiceImpl implements AthleteService {

	@Autowired
	AthleteRepo athleteRepo;
	
	@Override
	public List<Athlete> getAll() {
		List<Athlete> allPlayers = athleteRepo.findAll();
		return allPlayers;
	}
}
