package com.deloitte.athlete.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.deloitte.athlete.entity.Athlete;
@Repository
public interface AthleteRepo extends JpaRepository<Athlete, Integer> {

}
