package com.deloitte.athlete.service;

import java.util.List;

import com.deloitte.athlete.entity.Athlete;



public interface AthleteService {
	

		public List<Athlete> getAll();
	
}
