package com.deloitte.athlete.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Athlete {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int pnum;
	private String pname;
	private int cid;
	
	public Athlete() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Athlete(int pnum, String pname, int cid) {
		super();
		this.pnum=pnum;
		this.cid = cid;
		this.pname=pname;
	}
	
	public int getPnum() {
		return pnum;
	}
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
}